/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./ToggleButton/index.ts":
/*!*******************************!*\
  !*** ./ToggleButton/index.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   ToggleButton: () => (/* binding */ ToggleButton)\n/* harmony export */ });\nclass ToggleButton {\n  constructor() {\n    this.hexColorRegex = /^#(?:[0-9a-fA-F]{3}){1,2}$/;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n  init(context, notifyOutputChanged, state, container) {\n    var _a;\n    // Add control initialization code\n    this._booleanValue = context.parameters.ToggleValue.raw || false;\n    this._toggleColorValue = ((_a = context.parameters.ToggleColor.raw) === null || _a === void 0 ? void 0 : _a.length) == 7 ? context.parameters.ToggleColor.raw : \"#2196F3\";\n    this._toggleRound = context.parameters.ToggleRound.raw;\n    //label\n    this._toggleRoundLblElement = document.createElement(\"label\");\n    this._toggleRoundLblElement.setAttribute(\"class\", \"switch\");\n    //checkbox btn\n    this._toggleRoundBtnElement = document.createElement(\"input\");\n    this._toggleRoundBtnElement.setAttribute(\"type\", \"checkbox\");\n    if (!this.hexColorRegex.test(this._toggleColorValue)) {\n      this._toggleColorValue = \"#2196F3\";\n    }\n    if (this._booleanValue) {\n      this._toggleRoundBtnElement.setAttribute(\"checked\", \"true\");\n      document.documentElement.style.setProperty('--toggle-on-color', this._toggleColorValue);\n    } else {\n      this._toggleRoundBtnElement.removeAttribute(\"checked\");\n    }\n    //toggle round or not\n    if (this._toggleRound) {\n      document.documentElement.style.setProperty('--toggleRound', '34px');\n      document.documentElement.style.setProperty('--toggleRoundBefore', '50%');\n    } else {\n      document.documentElement.style.setProperty('--toggleRound', '0px');\n      document.documentElement.style.setProperty('--toggleRoundBefore', '0');\n    }\n    //\n    this._toggleRoundBtnElement.addEventListener(\"change\", event => {\n      this._booleanValue = this._toggleRoundBtnElement.checked;\n      notifyOutputChanged();\n    });\n    //span element\n    this._toggleRoundSpanElement = document.createElement(\"span\");\n    this._toggleRoundSpanElement.setAttribute(\"class\", \"slider round\");\n    //put checkboxbtn and span into label\n    //    console.log(\"init:\",this._booleanValue)\n    this._toggleRoundLblElement.appendChild(this._toggleRoundBtnElement);\n    this._toggleRoundLblElement.appendChild(this._toggleRoundSpanElement);\n    container.appendChild(this._toggleRoundLblElement);\n  }\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n  updateView(context) {\n    var _a;\n    // Add code to update control view\n    this._booleanValue = context.parameters.ToggleValue.raw;\n    this._toggleColorValue = ((_a = context.parameters.ToggleColor.raw) === null || _a === void 0 ? void 0 : _a.length) == 7 ? context.parameters.ToggleColor.raw : \"#2196F3\";\n    this._toggleRound = context.parameters.ToggleRound.raw;\n    this._toggleRoundBtnElement.setAttribute(\"type\", \"checkbox\");\n    if (!this.hexColorRegex.test(this._toggleColorValue)) {\n      this._toggleColorValue = \"#2196F3\";\n    }\n    if (this._booleanValue) {\n      this._toggleRoundBtnElement.setAttribute(\"checked\", \"true\");\n      document.documentElement.style.setProperty('--toggle-on-color', this._toggleColorValue);\n    } else {\n      this._toggleRoundBtnElement.removeAttribute(\"checked\");\n    }\n    //toggle round or not\n    if (this._toggleRound) {\n      document.documentElement.style.setProperty('--toggleRound', '34px');\n      document.documentElement.style.setProperty('--toggleRoundBefore', '50%');\n    } else {\n      document.documentElement.style.setProperty('--toggleRound', '0px');\n      document.documentElement.style.setProperty('--toggleRoundBefore', '0');\n    }\n    //\n  }\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as \"bound\" or \"output\"\r\n   */\n  getOutputs() {\n    return {\n      ToggleValue: this._booleanValue\n    };\n  }\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n  destroy() {\n    // Add code to cleanup control if necessary\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./ToggleButton/index.ts?");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./ToggleButton/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ToggleButton.ToggleButton', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ToggleButton);
} else {
	var ToggleButton = ToggleButton || {};
	ToggleButton.ToggleButton = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.ToggleButton;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}